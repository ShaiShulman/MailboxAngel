﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HelperUtils;

namespace FilingHelper.Controls.Settings
{
    public partial class HistoryManagersSettingsPanel : UserControl,ISettingsDialogPanel
    {
        public HistoryManagersSettingsPanel()
        {
            InitializeComponent();
        }

        public void LoadSettings()
        {
            Properties.AddinSettings.Default.Upgrade();
            txtMaxFolders.Value = Properties.AddinSettings.Default.FolderHistoryMaxItems;
            chkShowNeverOption.Checked = Properties.AddinSettings.Default.FolderHistoryAvoidVisible;
            chkShowPersistentOption.Checked = Properties.AddinSettings.Default.FolderHistoryPersistVisible;
            txtMaxMailItems.Value = Properties.AddinSettings.Default.MailHistoryMaxItems;
        }

        public void SaveSettings()
        {
            if (Properties.AddinSettings.Default.FolderHistoryMaxItems != txtMaxFolders.Value.TryParseInt(10))
            {
                Properties.AddinSettings.Default.FolderHistoryMaxItems = txtMaxFolders.Value.TryParseInt(10);
                Globals.ThisAddIn.FolderHistory.Resize(txtMaxMailItems.Value.TryParseInt(10));
            }

            Properties.AddinSettings.Default.FolderHistoryMaxItems = txtMaxFolders.Value.TryParseInt(10);
            Properties.AddinSettings.Default.FolderHistoryAvoidVisible = chkShowNeverOption.Checked;
            Properties.AddinSettings.Default.FolderHistoryPersistVisible = chkShowPersistentOption.Checked;
            if (Properties.AddinSettings.Default.MailHistoryMaxItems != txtMaxMailItems.Value.TryParseInt(10))
            {
                Properties.AddinSettings.Default.MailHistoryMaxItems = txtMaxMailItems.Value.TryParseInt(10);
                Globals.ThisAddIn.MailHistory.Resize(txtMaxMailItems.Value.TryParseInt(10));
            }
            Properties.AddinSettings.Default.Save();
        }

        private void btnResetHistory_Click(object sender, EventArgs e)
        {
            Globals.ThisAddIn.FolderHistory.ClearAll();
            btnResetHistory.Enabled = false;
        }
    }
}
