﻿using HelperUtils;
using Microsoft.Office.Interop.Outlook;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilingSuggester
{
    public class Suggester:JsonPersistent<Dictionary<string, CounterList<FolderKey>>>
    {
        const string FILE_NAME = "FilingSuggestion.json";
        private readonly OlDefaultFolders[] _ExcludedDefaultFolders = { OlDefaultFolders.olFolderInbox, OlDefaultFolders.olFolderDrafts, OlDefaultFolders.olFolderDeletedItems };
        private Microsoft.Office.Interop.Outlook.NameSpace _session;
        private Dictionary<string, CounterList<FolderKey>> _list;
        private List<string> _excludedFoldersEntryId;
        
        protected override string GetFileName()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), FILE_NAME);
        }
        public Suggester(Microsoft.Office.Interop.Outlook.NameSpace session,string[] excludedFoldersEntryId)
        {
            _list = new Dictionary<string, CounterList<FolderKey>>();
            _session = session;
            _excludedFoldersEntryId = excludedFoldersEntryId.ToList();
            populateDefaultExcludedFolders(_excludedFoldersEntryId);
        }

        public void Update(string recepient, Folder folder)
        {
            if (!_list.ContainsKey(recepient))
                _list.Add(recepient, new CounterList<FolderKey>(new FolderKey.EqualityComparer()));
            else
                _list[recepient].Add(new FolderKey(folder));
        }

        public Folder[] GetSuggestions(string recepient,int topItems)
        {
            if (_list.ContainsKey(recepient))
                return _list[recepient].GetTop(topItems).Where(y => !_excludedFoldersEntryId.Contains(y.Key)).Select(x=> x.OutlookFolder).ToArray();
            else
                return new Folder[0];
        }

        public void Save()
        {
            Save(SerializeJson());
        }

        public void Load()
        {
            string txt = LoadText();
            DeserializeJson(txt);
        }

        private void populateDefaultExcludedFolders(List<string> list)
        {
            foreach (var item in _ExcludedDefaultFolders)
            {
                Folder folder = (Folder)_session.GetDefaultFolder(item);
                if (folder != null)
                    list.Add(folder.EntryID);
            }
        }
        private string SerializeJson()
        {
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);
            using (JsonTextWriter writer = new JsonTextWriter(sw))
            {
                writer.WriteStartArray();
                writer.Formatting = Formatting.Indented;
                foreach (var item in _list)
                {
                    writer.WriteStartObject();
                    writer.WritePropertyName("Sender");
                    writer.WriteValue(item.Key);
                    //writer.WriteStartObject();
                    writer.WritePropertyName("Folders");
                    writer.WriteStartArray();
                    item.Value.WriteJson(writer);
                    writer.WriteEndArray();
                    writer.WriteEndObject();
                }
                writer.WriteEndArray();
            }
            return sb.ToString();
        }

        private void DeserializeJson(string json)
        {
            _list = new Dictionary<string, CounterList<FolderKey>>();
            dynamic jsonList = JsonConvert.DeserializeObject(json);
            foreach (var item in jsonList)
            {
                CounterList<FolderKey> foldersList = new CounterList<FolderKey>(new FolderKey.EqualityComparer());
                string senderName = item.Sender;
                foreach (var folder in item.Folders)
                {
                    Folder outlookFolder = (Folder)_session.GetFolderFromID(folder.Folder);
                    foldersList.Add(new FolderKey(outlookFolder), (int) folder.Counter);
                }
                _list.Add(senderName, foldersList);
            }
        }

        public void CreateSuggestionMenu(Microsoft.Office.Tools.Ribbon.RibbonMenu menu, Explorer explorer, Inspector inspector)
        {

        }
    }
}
